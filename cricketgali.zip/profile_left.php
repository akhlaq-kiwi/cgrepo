<div class="profile_image">
	<img src="<?php echo $general->url;?>/uploads/Thumb.php?path=users/<?php echo $image->profileImage($auth->USERID);?>&width=180" />
</div>
<div class="profile_menu">
	<ul>
		<li><a class="ajax" href="<?php echo $general->url;?>/home">Basic Info</a></li>
		<li><a class="ajax" href="<?php echo $general->url;?>/contact">Contact Info</a></li>
		<li><a class="ajax" href="<?php echo $general->url;?>/cricket_profile">Cricket Profile</a></li>
		<!--<li><a class="ajax" href="<?php echo $general->url;?>/cricket_career">Cricket Career</a></li>-->
		<li><a class="ajax" href="<?php echo $general->url;?>/upload_photo">Upload Photos</a></li>
		<li><a class="ajax" href="<?php echo $general->url;?>/my_teams">My Teams</a></li>
		<li><a class="ajax" href="<?php echo $general->url;?>/my_clubs">My CLUBS</a></li>
		<li><a class="ajax" href="<?php echo $general->url;?>/messages">Messages</a></li>
		<li><a class="ajax" href="<?php echo $general->url;?>/settings">Settings</a></li>
	</ul>
</div>