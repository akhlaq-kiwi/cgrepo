<?php
class User extends DB{
	public function register($data){
		if(is_array($data) && count($data)){
		
		}else{
		
		}
	}
}
?>