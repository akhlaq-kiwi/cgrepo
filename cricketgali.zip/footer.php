<div id="footer">
			<div id="footer_link">
				<ul>
					<li><a href="">Home</a></li>
					<li><a href="">About Us</a></li>
					<li><a href="">Contact Us</a></li>
					<li><a href="">Feedback</a></li>
					<li><a href="">Privacy Policy</a></li>
					<li class="nb"><a href="">Sitemap</a></li>
				</ul>
			</div>
			<div class="clr"></div>
			<div class="copyright">
				All Right Reserved &copy; CricketGali.com
			</div>
			
	</div>
	
 </body>
</html>