<?php
class Thumb{
	var $type;
	var $attr;
	var $height;
	var $width;
	function getImageInfo($path){
		
		list($this->width, $this->height, $type, $this->attr) = getimagesize($path);
		switch($type){
			case 1:
				$this->type = 'gif';
				break;
			case 2:
				$this->type = 'jpg';
				break;
			case 3:
				$this->type = 'png';
				break;
		}
	}
	
	function resizeWidth($path, $new_width){
		$this->getImageInfo($path);
		$new_height = ($this->height*(($new_width*100)/$this->width))/100;
		$this->generateThumb($path, $new_width,  $new_height);
	}
	function resizeHeight($path, $new_height){
		$this->getImageInfo($path);
		$new_width = ($this->width*(($new_height*100)/$this->height))/100;
		$this->generateThumb($path, $new_width,  $new_height);
	}

	function generateThumb($path, $new_width='',  $new_height=''){
		
		$this->getImageInfo($path);
		header("Content-Type: image/".$this->type);

		$tmp_img = imagecreatetruecolor($new_width,  $new_height);
		
		switch($this->type){
			case 'gif':
				$im = @imagecreatefromgif($path);
				imagecopyresampled($tmp_img, $im, 0, 0, 0, 0, $new_width, $new_height, $this->width, $this->height);
				imagegif($tmp_img);
				break;
			case 'jpg':
				$im = @imagecreatefromjpeg($path);
				imagecopyresampled($tmp_img, $im, 0, 0, 0, 0, $new_width, $new_height, $this->width, $this->height);
				imagejpeg($tmp_img);
				break;
			case 'png':
				$im = @imagecreatefrompng($path);
				imagecopyresampled($tmp_img, $im, 0, 0, 0, 0, $new_width, $new_height, $this->width, $this->height);
				imagepng($tmp_img);
				break;
		
		}
		
	}
}
$thmb = new Thumb;
if(isset($_GET['width']) && $_GET['width']!=''){
	if(!file_exists($_GET['path']))
		$_GET['path'] = 'users/noimage.jpg';
	$thmb->resizeWidth($_GET['path'], $_GET['width']);
}
?>
