<?php
include('includes/config.php');
$data['meta_title'] = 'Cricket Live Score | Live Match | Cricket Commentry';
$data['meta_keyword'] = 'Cricket Live Score, Live Match, Cricket Commentry';
$data['meta_description'] = 'Cricket gali.com provide Cricket Live Score, Live Match and Live Cricket Commentry';
?>

 <?php include('header-inner.php');?>
 <div id="content">
 <?php $auth->showMsg();?>
			<div id="general_left">
				<?php //include('state_city.php');?>
			</div>

			<div id="general_content">
				<h1 class="inner_title">Live Score Here!</h1>
				
			</div>
			<div id="general_right">
				 Ads here
			</div>
			<div class="clr"></div>
		</div>
	</div>
 <?php include('footer.php');?>
</body>
</html>
